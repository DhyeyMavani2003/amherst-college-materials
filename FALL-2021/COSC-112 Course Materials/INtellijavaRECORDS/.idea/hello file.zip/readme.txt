Programming Assignment: Hello, World


EXCEPTIONALLY, IN THIS ASSIGNMENT, YOU ARE ASKED TO SHARE YOUR PREFERRED NAME.

IN FUTURE ASSIGNMENTS, PLEASE REMEMBER NOT TO INCLUDE YOUR NAME (OR LATER IN
THE COURSE, YOUR PARTNER'S NAME) ANYWHERE IN THE SUBMISSION. THANK YOU!


/******************************************************************************
 ***            Some information to help us get to know you.                ***
 ******************************************************************************/

Preferred name (i.e., what you prefer to be called in class):

Year:

AB/BSE:

Possible major(s) (if you know or have an idea):

Confidence level (0 = very afraid, 5 = very confident) 0/1/2/3/4/5

Have you taken part of COS 126 before (YES/NO) ? If Yes, when?

Why are you interested in taking this course?

What are your other interests?


/**********************************************************************
 * Approximate number of hours to complete this assignment            *
 **********************************************************************/

Number of hours:



/******************************************************************************
 ***   Did you receive help from classmates, past COS 126 students, or      ***
 ***   anyone else? If so, please list their names. ("A Sunday lab TA"      ***
 ***   or "Office hours on Thursday" is ok if you don't know their name.)   ***
 ******************************************************************************/

Yes or no? 



/******************************************************************************
 ***   Did you encounter any serious problems? If yes, please describe.     ***
 ******************************************************************************/

Yes or no? 


/******************************************************************************
 ***   List any other comments here.                                        ***
 ******************************************************************************/
